"""
agent.py — LLM via Ollama with GPU-optimized settings
======================================================

Ollama automatically uses the GPU when available.
This module configures the request to get maximum GPU utilization:

  - num_gpu=-1    → load ALL layers onto GPU (no CPU offloading)
  - num_ctx=4096  → larger context fits in VRAM, better coherence
  - f16_kv=True   → KV cache in float16 (halves VRAM for cache)
  - low_vram=False→ don't sacrifice quality for VRAM savings
  - num_predict=150 → capped for voice responses (short = fast)
  - repeat_penalty=1.1 → slight repetition penalty
  - temperature=0.7   → natural, not robotic

GPU LLM options ranked by quality/speed tradeoff:
  llama3:8b-instruct-q8_0   → 8GB VRAM, best quality at 8B
  llama3:8b-instruct-q4_K_M → 5GB VRAM, excellent quality/size ratio
  mistral:7b-instruct-q4_K_M→ 4.5GB VRAM, very fast
  phi3:mini-instruct         → 2.5GB VRAM, surprisingly capable
  llama3:70b-instruct-q4_K_M → 40GB VRAM, best quality

Pull command: ollama pull llama3:8b-instruct-q4_K_M
"""

import os
import json
import asyncio
import logging
import httpx
from typing import AsyncIterator
from dotenv import load_dotenv

load_dotenv()
log = logging.getLogger("agent")

OLLAMA_BASE  = os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434")
MODEL        = os.environ.get("LLM_MODEL",       "llama3:8b-instruct-q4_K_M")
CUDA_LAYERS  = int(os.environ.get("LLM_GPU_LAYERS", "-1"))   # -1 = all layers on GPU

log.info(f"[agent] LLM: {MODEL} via Ollama at {OLLAMA_BASE} (gpu_layers={CUDA_LAYERS})")

# ── System prompt ─────────────────────────────────────────────────────────────
SYSTEM_PROMPT = """You are a helpful, friendly voice assistant.
Your responses are spoken aloud by a text-to-speech system.

RESPONSE RULES:
Keep every response to one or two short sentences unless detail is requested.
Never use markdown, bullet points, asterisks, or pound signs.
Always end sentences with proper punctuation.
Use natural contractions: I'm, we're, that's, it's.
Spell out numbers: twenty-five, not 25.
If asked for many items, give the top two or three.

EMOTION TAGS — strip from speech, used for voice modulation:
[excited]That's incredible!
[warm]Welcome!
[confident]I can definitely help with that.
[curious]What would you like to know?

Available: excited, warm, confident, curious, hmm, laugh, neutral
Rules: one tag per response, lowercase, at phrase start, not at end.

STYLE:
Occasionally open with: So, Well, Sure, Great question.
Never repeat the same opener twice in a row.
Sound warm and genuinely helpful.
If interrupted: start with "Of course" or "Sure".
Always respond in English."""

# ── History ───────────────────────────────────────────────────────────────────
_histories: dict[str, list[dict]] = {}

def _get_history(sid: str) -> list[dict]:
    return _histories.setdefault(sid, [])

def append_user(sid: str, text: str):
    _get_history(sid).append({"role": "user", "content": text})

def append_assistant(sid: str, text: str):
    _get_history(sid).append({"role": "assistant", "content": text})

def truncate_last_assistant(sid: str, spoken: str):
    h = _get_history(sid)
    if h and h[-1]["role"] == "assistant":
        if spoken.strip():
            h[-1]["content"] = spoken
        else:
            h.pop()


# ── Ollama streaming ──────────────────────────────────────────────────────────

async def _stream_ollama(messages: list[dict]) -> AsyncIterator[str]:
    """
    POST /api/chat with stream=True to local Ollama.
    GPU options passed in the 'options' block:
      num_gpu=-1    → all transformer layers on GPU
      f16_kv=True   → KV cache in float16 (saves VRAM, no quality loss)
      num_ctx=4096  → larger context window fits in VRAM
    """
    payload = {
        "model":   MODEL,
        "messages": messages,
        "stream":  True,
        "options": {
            # ── GPU ───────────────────────────────────────────────────────────
            "num_gpu":        CUDA_LAYERS,   # -1 = all layers
            "f16_kv":         True,          # float16 KV cache
            "low_vram":       False,         # don't sacrifice quality
            "numa":           False,

            # ── Inference ────────────────────────────────────────────────────
            "num_ctx":        4096,          # context window
            "num_predict":    150,           # max tokens (short for voice)
            "temperature":    0.7,
            "top_p":          0.9,
            "top_k":          40,
            "repeat_penalty": 1.1,
            "num_thread":     4,             # CPU threads for non-GPU work

            # ── Speed ────────────────────────────────────────────────────────
            "num_batch":      512,           # batch size for prompt processing
        },
    }

    timeout = httpx.Timeout(60.0, connect=10.0, read=30.0)

    async with httpx.AsyncClient(timeout=timeout) as client:
        async with client.stream("POST", f"{OLLAMA_BASE}/api/chat", json=payload) as resp:
            if resp.status_code != 200:
                body = await resp.aread()
                raise RuntimeError(
                    f"Ollama {resp.status_code}: {body.decode()[:200]}"
                )
            async for line in resp.aiter_lines():
                if not line.strip():
                    continue
                try:
                    chunk = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if chunk.get("done"):
                    break
                content = chunk.get("message", {}).get("content", "")
                if content:
                    yield content
                    await asyncio.sleep(0)


# ── Main entry point ──────────────────────────────────────────────────────────

async def chat_stream(
    user_text: str,
    session_id: str,
    was_interrupted: bool = False,
) -> AsyncIterator[str]:
    """Stream LLM tokens from local Ollama (GPU-accelerated)."""

    log.debug(f"[{session_id}] chat_stream: {user_text!r}")

    effective = (
        f"[previous response was interrupted] {user_text}"
        if was_interrupted else user_text
    )
    append_user(session_id, effective)

    history  = _get_history(session_id)[-10:]   # slightly more history with GPU
    messages = [{"role": "system", "content": SYSTEM_PROMPT}] + history

    full_response = ""

    try:
        async for token in _stream_ollama(messages):
            full_response += token
            yield token

        append_assistant(session_id, full_response)
        log.debug(f"[{session_id}] done ({len(full_response)} chars)")

    except asyncio.CancelledError:
        truncate_last_assistant(session_id, full_response)
        log.info(f"[{session_id}] cancelled ({len(full_response)} chars spoken)")
        raise

    except httpx.ConnectError:
        truncate_last_assistant(session_id, full_response)
        msg = "I can't reach the local language model. Please run: ollama serve"
        yield msg
        append_assistant(session_id, msg)
        log.error(f"[{session_id}] Ollama connection refused")

    except Exception as e:
        truncate_last_assistant(session_id, full_response)
        log.exception(f"[{session_id}] error: {e}")
        raise
