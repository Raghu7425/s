"""
generate_sounds.py — Run ONCE to generate audio clips for sounds/
==================================================================

Generates three MP3 clips using edge-tts.
Run from your project root:

    python generate_sounds.py

Requires edge-tts installed: pip install edge-tts
"""

import asyncio
import os
import edge_tts

VOICE = "en-US-AriaNeural"
SOUNDS_DIR = os.path.join(os.path.dirname(__file__), "sounds")
os.makedirs(SOUNDS_DIR, exist_ok=True)

CLIPS = {
    "hmm.mp3": {
        "text": "Hmm.", "rate": "-20%", "pitch": "-8Hz", "volume": "+0%",
    },
    "laugh_light.mp3": {
        "text": "Ha, that's a good one.", "rate": "+15%", "pitch": "+10Hz", "volume": "+5%",
    },
    "breath.mp3": {
        "text": "Well,", "rate": "-25%", "pitch": "-5Hz", "volume": "-5%",
    },
}

async def generate_clip(filename, cfg):
    path = os.path.join(SOUNDS_DIR, filename)
    communicate = edge_tts.Communicate(
        cfg["text"], VOICE,
        rate=cfg["rate"], pitch=cfg["pitch"], volume=cfg["volume"],
    )
    await communicate.save(path)
    size = os.path.getsize(path)
    print(f"  ✓ {filename} ({size} bytes)")

async def main():
    print(f"Generating {len(CLIPS)} sound clips into sounds/...\n")
    for filename, cfg in CLIPS.items():
        await generate_clip(filename, cfg)
    print("\nDone.")

if __name__ == "__main__":
    asyncio.run(main())
