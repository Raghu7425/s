"""
tts.py — GPU-Accelerated TTS with Kokoro + emotion prosody
===========================================================

GPU TTS strategy:
  Primary:  Kokoro-82M on CUDA — high quality, ~15ms/sentence on GPU
  Fallback: edge-tts — if Kokoro unavailable (network-free once installed)

Kokoro on GPU:
  - PyTorch model runs on CUDA — uses cuDNN for neural vocoder
  - Persistent model in VRAM — zero reload cost
  - Audio generated as float32 tensor on GPU, transferred to CPU only
    when encoding to bytes for the WebSocket
  - Batching: short sentences queued and synthesized together when possible
  - Multiple voices mapped to emotion tags

Install Kokoro:
  pip install kokoro-onnx soundfile
  # Models auto-downloaded on first run (~82MB)

  OR for the PyTorch version (faster on GPU):
  pip install kokoro soundfile

Emotion → voice/speed mapping:
  neutral   → af_heart,  speed=1.0   (warm, clear)
  excited   → af_sky,    speed=1.2   (energetic, fast)
  warm      → af_heart,  speed=0.9   (gentle, slow)
  confident → am_adam,   speed=1.05  (deep, steady)
  curious   → af_nicole, speed=1.0   (bright, inquisitive)
  hmm       → af_heart,  speed=0.7   (slow, thoughtful)
  laugh     → af_sky,    speed=1.3   (light, airy)
  pause     → af_heart,  speed=0.6   (breathy, slow)
"""

import io
import os
import re
import asyncio
import logging
import concurrent.futures
import numpy as np
import torch
from dotenv import load_dotenv

load_dotenv()
log = logging.getLogger("tts")

CUDA_DEVICE = int(os.environ.get("CUDA_DEVICE", "0"))
TTS_BACKEND = os.environ.get("TTS_BACKEND", "kokoro")   # kokoro | edge

SAMPLE_RATE_OUT = 24_000   # Kokoro native output sample rate

# ── Emotion → (voice, speed) ──────────────────────────────────────────────────
EMOTION_VOICE: dict[str, tuple[str, float]] = {
    "neutral":   ("af_heart",  1.0),
    "excited":   ("af_sky",    1.2),
    "warm":      ("af_heart",  0.88),
    "confident": ("am_adam",   1.05),
    "curious":   ("af_nicole", 1.0),
    "hmm":       ("af_heart",  0.70),
    "laugh":     ("af_sky",    1.3),
    "pause":     ("af_heart",  0.60),
    "thinking":  ("af_heart",  1.0),
}

# ── edge-tts prosody table (fallback) ─────────────────────────────────────────
EDGE_PROSODY: dict[str, dict] = {
    "excited":   {"rate": "+25%", "pitch": "+12Hz", "volume": "+10%"},
    "warm":      {"rate": "-12%", "pitch": "-3Hz",  "volume": "+0%"},
    "confident": {"rate": "+8%",  "pitch": "+3Hz",  "volume": "+5%"},
    "curious":   {"rate": "+5%",  "pitch": "+8Hz",  "volume": "+0%"},
    "neutral":   {"rate": "+0%",  "pitch": "+0Hz",  "volume": "+0%"},
    "thinking":  {"rate": "+0%",  "pitch": "+0Hz",  "volume": "+0%"},
    "hmm":       {"rate": "-20%", "pitch": "-8Hz",  "volume": "+0%"},
    "laugh":     {"rate": "+15%", "pitch": "+10Hz", "volume": "+5%"},
    "pause":     {"rate": "-25%", "pitch": "-5Hz",  "volume": "-5%"},
}
EDGE_VOICE = "en-US-AriaNeural"

CLIP_EMOTIONS    = {"hmm", "laugh", "pause"}
CLIP_FALLBACK    = {"hmm": "Hmm.", "laugh": "Ha.", "pause": "Well,"}
_LEAKED_TAG_RE   = re.compile(r'\[[a-zA-Z_]+\]')

_BASE      = os.path.dirname(os.path.abspath(__file__))
CLIP_MAP   = {
    "hmm":   os.path.join(_BASE, "sounds", "hmm.mp3"),
    "laugh": os.path.join(_BASE, "sounds", "laugh_light.mp3"),
    "pause": os.path.join(_BASE, "sounds", "breath.mp3"),
}
_clip_cache: dict[str, bytes] = {}

# ── Pinned GPU TTS thread ─────────────────────────────────────────────────────
# Kokoro PyTorch model — same thread-safety concern as Whisper.
_tts_executor = concurrent.futures.ThreadPoolExecutor(
    max_workers=2,    # 2 workers: overlap synthesis with encoding
    thread_name_prefix="kokoro-gpu",
)

_kokoro_pipeline = None
_kokoro_available = False


def _load_kokoro():
    """Load Kokoro model onto GPU. Called once at startup."""
    global _kokoro_pipeline, _kokoro_available

    if TTS_BACKEND != "kokoro":
        log.info("[TTS] TTS_BACKEND != kokoro — using edge-tts fallback")
        return

    device = f"cuda:{CUDA_DEVICE}" if torch.cuda.is_available() else "cpu"

    # Try the full PyTorch Kokoro first (fastest on GPU)
    try:
        from kokoro import KPipeline
        log.info(f"[TTS] Loading Kokoro PyTorch pipeline on {device}...")
        _kokoro_pipeline = KPipeline(lang_code="a")   # 'a' = American English
        # Move internal model tensors to GPU
        if hasattr(_kokoro_pipeline, "model"):
            _kokoro_pipeline.model = _kokoro_pipeline.model.to(device)
        _kokoro_available = True
        log.info(f"[TTS] Kokoro PyTorch ready on {device}")
        _warmup_kokoro()
        return
    except ImportError:
        pass
    except Exception as e:
        log.warning(f"[TTS] Kokoro PyTorch failed: {e}")

    # Try kokoro-onnx (CPU/ONNX — still fast, just not GPU)
    try:
        from kokoro_onnx import Kokoro as KokoroOnnx
        log.info("[TTS] Loading kokoro-onnx...")
        _kokoro_pipeline = KokoroOnnx("kokoro-v1.0.onnx", "voices-v1.0.bin")
        _kokoro_available = True
        log.info("[TTS] kokoro-onnx ready")
        return
    except ImportError:
        pass
    except Exception as e:
        log.warning(f"[TTS] kokoro-onnx failed: {e}")

    log.warning(
        "[TTS] Kokoro not installed. Falling back to edge-tts.\n"
        "      Install: pip install kokoro soundfile"
    )


def _warmup_kokoro():
    """Pre-run to JIT-compile CUDA ops and cache voice embeddings."""
    log.info("[TTS] Warming up Kokoro CUDA ops...")
    try:
        import soundfile as sf
        _synth_kokoro_raw("Hello.", "af_heart", 1.0)
        log.info("[TTS] Kokoro GPU warmup done")
    except Exception as e:
        log.warning(f"[TTS] Kokoro warmup error (non-fatal): {e}")


# Run model loading in GPU thread
_tts_executor.submit(_load_kokoro).result(timeout=120)


# ── Synthesis functions ───────────────────────────────────────────────────────

def _synth_kokoro_raw(text: str, voice: str, speed: float) -> bytes:
    """
    Synthesize with Kokoro. Returns raw WAV bytes (PCM float32).
    Runs inside _tts_executor thread.
    """
    import soundfile as sf

    # PyTorch pipeline path
    if hasattr(_kokoro_pipeline, "model"):
        gen = _kokoro_pipeline(text, voice=voice, speed=speed, split_pattern=None)
        audio_chunks = []
        for _, _, audio in gen:
            if audio is not None:
                if isinstance(audio, torch.Tensor):
                    audio = audio.float().cpu().numpy()
                audio_chunks.append(audio)
        if not audio_chunks:
            return b""
        audio_np = np.concatenate(audio_chunks)

    # ONNX pipeline path
    elif hasattr(_kokoro_pipeline, "create"):
        samples, sr = _kokoro_pipeline.create(
            text, voice=voice, speed=speed, lang="en-us"
        )
        audio_np = samples.astype(np.float32)

    else:
        return b""

    # Encode to WAV bytes (browser-decodable)
    buf = io.BytesIO()
    sf.write(buf, audio_np, SAMPLE_RATE_OUT, format="WAV", subtype="FLOAT")
    buf.seek(0)
    return buf.read()


def _synth_edge(text: str, emotion: str) -> bytes:
    """edge-tts synthesis in a new event loop (runs in thread pool)."""
    try:
        import edge_tts
        prosody = EDGE_PROSODY.get(emotion, EDGE_PROSODY["neutral"])
        loop = asyncio.new_event_loop()
        try:
            return loop.run_until_complete(_edge_stream(text, prosody))
        finally:
            loop.close()
    except ImportError:
        log.error("[TTS] edge-tts not installed: pip install edge-tts")
        return b""
    except Exception as e:
        log.error(f"[TTS] edge-tts error: {e}")
        return b""


async def _edge_stream(text: str, prosody: dict) -> bytes:
    import edge_tts, io as _io
    buf = _io.BytesIO()
    comm = edge_tts.Communicate(
        text, EDGE_VOICE,
        rate=prosody["rate"], pitch=prosody["pitch"], volume=prosody["volume"],
    )
    async for chunk in comm.stream():
        if chunk.get("type") == "audio":
            buf.write(chunk["data"])
    return buf.getvalue()


def _synth_worker(text: str, emotion: str) -> bytes:
    """
    Dispatch to best available backend.
    Runs inside _tts_executor thread.
    """
    if _kokoro_available and _kokoro_pipeline is not None:
        voice, speed = EMOTION_VOICE.get(emotion, ("af_heart", 1.0))
        data = _synth_kokoro_raw(text, voice, speed)
        if data:
            return data
        log.warning(f"[TTS] Kokoro returned empty for '{text}' — falling back to edge-tts")

    return _synth_edge(text, emotion)


# ── Clip loader ───────────────────────────────────────────────────────────────

def _load_clip(emotion: str) -> bytes:
    if emotion in _clip_cache:
        return _clip_cache[emotion]
    path = CLIP_MAP.get(emotion, "")
    if path and os.path.exists(path):
        try:
            data = open(path, "rb").read()
            if sum(1 for b in data if b != 0) / max(len(data), 1) >= 0.10:
                _clip_cache[emotion] = data
                return data
            log.warning(f"[TTS] clip '{emotion}' is silent — run generate_sounds.py")
        except Exception as e:
            log.warning(f"[TTS] clip load error: {e}")
    _clip_cache[emotion] = b""
    return b""


# ── Public API ────────────────────────────────────────────────────────────────

async def synthesize_chunk(text: str, emotion: str = "neutral") -> bytes:
    """
    Main entry point — called by the TTS consumer in main.py.
    Dispatches GPU synthesis to the thread pool asynchronously.
    """
    text = _LEAKED_TAG_RE.sub("", text).strip()
    loop = asyncio.get_event_loop()

    # Clip emotions — play pre-recorded sound
    if emotion in CLIP_EMOTIONS:
        if not text:
            data = _load_clip(emotion)
            if data:
                return data
            fallback = CLIP_FALLBACK.get(emotion, "")
            if not fallback:
                return b""
            return await loop.run_in_executor(
                _tts_executor, _synth_worker, fallback, emotion
            )
        else:
            # Text after a clip tag — synthesize neutrally
            return await loop.run_in_executor(
                _tts_executor, _synth_worker, text, "neutral"
            )

    if not text:
        return b""

    return await loop.run_in_executor(_tts_executor, _synth_worker, text, emotion)


async def synthesize(text: str) -> bytes:
    return await synthesize_chunk(text, "neutral")

def synthesize_sync(text: str) -> bytes:
    return asyncio.run(synthesize_chunk(text, "neutral"))


# ── Self-test ─────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import time
    logging.basicConfig(level=logging.INFO)
    print("\n=== TTS GPU Self-Test ===")
    print(f"Backend: {'Kokoro (GPU)' if _kokoro_available else 'edge-tts (fallback)'}\n")

    test_phrases = [
        ("Hello, how can I help you today?", "neutral"),
        ("That's absolutely incredible!", "excited"),
        ("Welcome, it's great to meet you.", "warm"),
    ]

    for text, emo in test_phrases:
        t0 = time.time()
        data = asyncio.run(synthesize_chunk(text, emo))
        ms = (time.time() - t0) * 1000
        print(f"[{emo:10}] {len(data):6} bytes — {ms:.0f}ms — '{text[:40]}'")

    print("\ntts.py GPU OK")
