# GPU Voice Agent — Full CUDA Pipeline

Everything runs on GPU. Zero API keys. Zero cloud calls.

```
Mic → VAD (Silero/CUDA) → STT (Whisper/CUDA) → LLM (Ollama/CUDA) → TTS (Kokoro/CUDA) → Speaker
```

## GPU utilization per component

| Component | Library | VRAM | Latency | Notes |
|-----------|---------|------|---------|-------|
| VAD | silero-vad on CUDA | ~10 MB | <1ms | Pre-allocated tensor, no alloc per frame |
| STT | faster-whisper large-v3, float16 | ~3.0 GB | ~90ms | Pinned GPU thread, CUDA warmup at startup |
| LLM | Ollama + llama3 8B q4_K_M, num_gpu=-1 | ~5.0 GB | ~500ms TTFT | All transformer layers on GPU |
| TTS | Kokoro-82M PyTorch on CUDA | ~300 MB | ~15ms | Pinned GPU thread pool, JIT warmup |
| **Total** | | **~8.8 GB** | **<650ms** | Fits RTX 3090 / 4090 |

---

## Quick Start

### 1. Install CUDA Toolkit 12.1+
https://developer.nvidia.com/cuda-downloads

Verify: `nvidia-smi`

### 2. Install PyTorch with CUDA

```bash
pip install torch==2.3.1 torchaudio==2.3.1 --index-url https://download.pytorch.org/whl/cu121
python -c "import torch; print(torch.cuda.get_device_name(0))"
```

### 3. Install Python dependencies

```bash
pip install -r requirements.txt
```

### 4. Install Kokoro TTS (GPU)

```bash
pip install kokoro soundfile
```

If Kokoro fails to install, the system automatically falls back to edge-tts.

### 5. Install and start Ollama

```bash
# Linux/macOS
curl -fsSL https://ollama.com/install.sh | sh

# Pull recommended GPU model (~4.7GB download)
ollama pull llama3:8b-instruct-q4_K_M

# Start server (Ollama auto-detects your GPU)
ollama serve
```

### 6. Configure

```bash
cp .env.example .env
# Edit .env if you need to change model sizes for your VRAM
```

### 7. Generate sound clips

```bash
python generate_sounds.py
```

### 8. Start the server

```bash
mkdir -p static && cp index.html static/
python main.py
```

Open http://localhost:8000

---

## VRAM sizing guide

| GPU | VRAM | Recommended config |
|-----|------|--------------------|
| RTX 4090 / 3090 | 24 GB | `large-v3` + `llama3:8b-instruct-q8_0` |
| RTX 4080 / 3080 12GB | 12 GB | `large-v3` + `llama3:8b-instruct-q4_K_M` |
| RTX 3080 10GB | 10 GB | `medium` + `llama3:8b-instruct-q4_K_M` |
| RTX 3070 / 4060 Ti | 8 GB | `small` + `phi3:mini-instruct` |
| RTX 3060 | 6 GB | `small` + `phi3:mini-instruct` |

---

## Architecture

### Why a pinned GPU thread for STT?

CTranslate2 (faster-whisper's backend) creates a CUDA context on the thread that loads the model. All subsequent inference calls must originate from that same thread. `_gpu_executor = ThreadPoolExecutor(max_workers=1)` pins all STT calls to a single thread, guaranteeing CUDA context safety.

### Why `asyncio.to_thread` instead of `run_in_executor`?

`asyncio.to_thread(fn)` is equivalent to `loop.run_in_executor(None, fn)` but uses the default thread pool. For STT we use `loop.run_in_executor(_gpu_executor, fn)` to dispatch to our specific pinned thread.

### Why `num_workers=1` in WhisperModel?

With `num_workers>1`, CTranslate2 creates internal threads that can conflict with the CUDA context. `num_workers=1` keeps all operations on the single pinned thread.

### CUDA warmup

At startup, a 1-second silence clip is pushed through Whisper and Kokoro before the WebSocket server accepts connections. This pre-compiles CUDA kernels (cuBLAS, cuDNN ops) so the **first real utterance** gets full speed, not 3-5x slower kernel compilation latency.

### VAD GPU optimization

Silero VAD is loaded onto CUDA with `vad_model.to("cuda")`. A single tensor `_vad_tensor = torch.zeros(1, 512, device="cuda")` is pre-allocated and reused for every 512-sample frame — avoiding repeated `torch.zeros()` GPU allocation calls per frame.

---

## Live monitoring

- GPU VRAM bar: visible in footer — polls `/gpu` every 4 seconds
- Health badges: VAD / STT / LLM / TTS — polls `/health` on connect
- Debug drawer: click "debug ⌥" — shows all events with timing

API endpoints:
- `GET /health` — full component status JSON
- `GET /gpu` — live VRAM stats (allocated, reserved, total, free)

---

## Troubleshooting

**CUDA out of memory**
→ Reduce `STT_MODEL` (large-v3 → medium → small)
→ Or use a smaller Ollama model: `phi3:mini-instruct`
→ Check with `nvidia-smi` what else is using VRAM

**"CUDA error: device-side assert triggered"**
→ Usually a dtype mismatch. Ensure `STT_COMPUTE=float16` (not float32 on GPU)

**Kokoro not installing**
→ `pip install kokoro soundfile` — if it fails, set `TTS_BACKEND=edge` in .env

**Ollama model too slow**
→ Check `ollama ps` — if "CPU" shows, Ollama didn't detect your GPU
→ Set `OLLAMA_ORIGINS=*` env var and restart Ollama
→ Or reinstall Ollama after CUDA drivers

**CTranslate2 CUDA not found**
→ `pip install ctranslate2` — it auto-detects CUDA from your torch installation
→ Verify with: `python -c "import ctranslate2; print(ctranslate2.get_supported_compute_types('cuda'))"`
