"""
tag_parser.py — Emotion tag state machine
==========================================

Sits between the raw LLM token stream and the TTS queue.
Detects inline emotion tags like [excited], [warm], [laugh] etc.,
strips them from display text, and emits (clean_text, emotion) pairs
for the TTS pipeline to consume.

Usage:
    parser = TagParser()

    for token in llm_stream:
        for clean_text, emotion in parser.feed(token):
            tts_queue.put((clean_text, emotion))
        display = parser.get_display_text(token)
        ui.show(display)

    clean, emotion = parser.flush()   # end of stream
    if clean:
        tts_queue.put((clean, emotion))
"""

import re
import logging

log = logging.getLogger("tag_parser")

KNOWN_TAGS = {
    "excited", "warm", "laugh", "pause", "confident",
    "curious", "hmm", "neutral", "thinking",
}

CLIP_TAGS = {"laugh", "hmm", "pause"}
MAX_TAG_BUFFER = 25
_TAG_RE = re.compile(r'\[[a-zA-Z_]+\]')


class TagParser:
    def __init__(self):
        self.reset()

    def reset(self):
        self.current_emotion: str = "neutral"
        self._buf: str = ""
        self._in_tag: bool = False
        self._tag_buf: str = ""
        self._text_buf: str = ""

    def feed(self, token: str) -> list[tuple[str, str]]:
        results: list[tuple[str, str]] = []
        self._buf += token
        i = 0
        while i < len(self._buf):
            ch = self._buf[i]
            if self._in_tag:
                if ch == ']':
                    tag = self._tag_buf.lower().strip()
                    self._in_tag  = False
                    self._tag_buf = ""
                    if tag in KNOWN_TAGS:
                        if self._text_buf.strip():
                            results.append((self._text_buf, self.current_emotion))
                            self._text_buf = ""
                        self.current_emotion = tag
                        if tag in CLIP_TAGS:
                            results.append(("", tag))
                    else:
                        self._text_buf += f"[{tag}]"
                elif ch == '[':
                    self._text_buf += f"[{self._tag_buf}"
                    self._tag_buf  = ""
                else:
                    self._tag_buf += ch
                    if len(self._tag_buf) > MAX_TAG_BUFFER:
                        self._text_buf += f"[{self._tag_buf}"
                        self._tag_buf  = ""
                        self._in_tag   = False
            else:
                if ch == '[':
                    self._in_tag  = True
                    self._tag_buf = ""
                else:
                    self._text_buf += ch
                    if ch in '.!?' and len(self._text_buf.strip()) >= 10 and not self._in_tag:
                        results.append((self._text_buf, self.current_emotion))
                        self._text_buf = ""
            i += 1

        self._buf = ""

        if len(self._text_buf) >= 80 and not self._in_tag:
            results.append((self._text_buf, self.current_emotion))
            self._text_buf = ""

        return results

    def flush(self) -> tuple[str, str]:
        text = self._text_buf
        if self._in_tag and self._tag_buf:
            text += f"[{self._tag_buf}"
        self._text_buf = ""
        self._in_tag   = False
        self._tag_buf  = ""
        return (text.strip(), self.current_emotion)

    def get_display_text(self, token: str) -> str:
        return _TAG_RE.sub('', token)

    @property
    def current_emotion(self) -> str:
        return self._current_emotion

    @current_emotion.setter
    def current_emotion(self, value: str):
        self._current_emotion = value if value in KNOWN_TAGS else "neutral"
