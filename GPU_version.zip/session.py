"""
session.py — Session state, registry, and task management
==========================================================

Manages per-client session state including:
  - Stable reconnect_token so history survives WebSocket drops
  - Task handles (llm_task, tts_task) with cancel_generation()
  - Serialized send_queue — one sender task drains all outgoing messages
  - ping_missed counter for keepalive tracking
  - was_interrupted flag for LLM recovery prompt

Session registry:
    get_or_create(reconnect_token, session_id) → SessionState
    Restores existing session if reconnect_token matches, else creates new.
"""

import asyncio
import uuid
import logging

log = logging.getLogger("session")


class SessionState:
    """All mutable state for one client session."""

    # ── Agent states ──────────────────────────────────────────────────────────
    IDLE        = "idle"
    LISTENING   = "listening"
    PROCESSING  = "processing"
    SPEAKING    = "speaking"
    INTERRUPTED = "interrupted"

    def __init__(self, session_id: str):
        self.id              = session_id
        self.reconnect_token = str(uuid.uuid4())
        self.connected       = True

        self.state = self.IDLE

        self.speech_buffer: list  = []
        self.speech_active        = False
        self.silence_time         = 0.0
        self.partial_timer        = 0.0
        self.barge_hold_secs      = 0.0

        self.cancel_event: asyncio.Event = asyncio.Event()
        self.gen_id: str = ""
        self.was_interrupted = False

        self.llm_task:  asyncio.Task | None = None
        self.tts_task:  asyncio.Task | None = None
        self.tts_queue: asyncio.Queue       = asyncio.Queue(maxsize=6)
        self.send_queue: asyncio.Queue      = asyncio.Queue()

        self.ping_missed = 0

        log.info(f"[{self.id}] session created (token={self.reconnect_token[:8]}…)")

    def set_state(self, new_state: str):
        log.info(f"[{self.id}] state: {self.state} → {new_state}")
        self.state = new_state

    def new_generation(self) -> str:
        self.cancel_event = asyncio.Event()
        self.gen_id = str(uuid.uuid4())[:8]
        log.debug(f"[{self.id}] new generation → {self.gen_id}")
        return self.gen_id

    async def cancel_generation(self):
        """Cancel LLM and TTS tasks immediately."""
        tasks = [t for t in [self.llm_task, self.tts_task] if t is not None]
        if tasks:
            for t in tasks:
                t.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
            log.debug(f"[{self.id}] {len(tasks)} task(s) cancelled")

        self.llm_task = None
        self.tts_task = None

        drained = 0
        while not self.tts_queue.empty():
            try:
                self.tts_queue.get_nowait()
                drained += 1
            except asyncio.QueueEmpty:
                break

        if drained:
            log.debug(f"[{self.id}] drained {drained} stale TTS queue item(s)")

        self.tts_queue = asyncio.Queue(maxsize=6)

    def reset_speech(self):
        self.speech_buffer   = []
        self.speech_active   = False
        self.silence_time    = 0.0
        self.partial_timer   = 0.0
        self.barge_hold_secs = 0.0

    def truncate_last_assistant(self, spoken_text: str):
        from agent import truncate_last_assistant as _trunc
        _trunc(self.id, spoken_text)


# ── Session registry ──────────────────────────────────────────────────────────
_registry: dict[str, "SessionState"] = {}


def get_or_create(reconnect_token: str | None, session_id: str) -> "SessionState":
    if reconnect_token and reconnect_token in _registry:
        s = _registry[reconnect_token]
        s.connected   = True
        s.ping_missed = 0
        log.info(f"[{s.id}] session RESTORED (token={reconnect_token[:8]}…)")
        s.state = SessionState.IDLE
        return s

    s = SessionState(session_id)
    _registry[s.reconnect_token] = s
    log.info(f"[{s.id}] new session registered")
    return s


def all_sessions() -> list["SessionState"]:
    return list(_registry.values())
