"""
main.py — GPU Voice Agent — Full CUDA Pipeline
===============================================

GPU utilization per component:
  VAD   → Silero model on CUDA (torch.cuda) — inference in GPU thread
  STT   → faster-whisper large-v3 on CUDA — pinned GPU thread
  LLM   → Ollama with num_gpu=-1 (all layers on GPU) — async HTTP stream
  TTS   → Kokoro-82M on CUDA (or edge-tts fallback) — GPU thread pool

CPU is used only for:
  - asyncio event loop coordination
  - WebSocket send/receive
  - Audio PCM conversion (int16 ↔ float32, trivially fast)

CUDA memory optimization:
  - VAD model: ~10MB VRAM (Silero is tiny)
  - STT model: ~3GB VRAM (Whisper large-v3 float16)
  - LLM model: ~5GB VRAM (llama3 8B q4_K_M via Ollama)
  - TTS model: ~0.3GB VRAM (Kokoro 82M)
  Total:       ~8.3GB VRAM — fits comfortably on RTX 3080/3090/4080/4090

  For 8GB cards: use STT_MODEL=medium (saves ~1.5GB), total ~6.8GB
  For 6GB cards: use STT_MODEL=small + LLM_MODEL=phi3, total ~4GB
"""

import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
os.environ["TOKENIZERS_PARALLELISM"] = "false"   # suppress HF warning on GPU

import asyncio
import uuid
import json
import logging
import numpy as np
import torch

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Query
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

from tts import synthesize_chunk
from agent import chat_stream, OLLAMA_BASE, MODEL
from tag_parser import TagParser
from session import SessionState, get_or_create
from stt import transcribe, gpu_stats as stt_gpu_stats

load_dotenv()

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("voice-agent")

# ── App ───────────────────────────────────────────────────────────────────────
app = FastAPI(title="GPU Voice Agent")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=True,
    allow_methods=["*"], allow_headers=["*"],
)
app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/")
async def root():
    return FileResponse("static/index.html")


# ── GPU health + telemetry ────────────────────────────────────────────────────

@app.get("/health")
async def health():
    """System health check — all component status + GPU telemetry."""
    from stt import _model as stt_model, STT_MODEL, STT_DEVICE, STT_COMPUTE

    # Check Ollama
    import httpx
    ollama_ok, ollama_model_loaded = False, False
    try:
        async with httpx.AsyncClient(timeout=2.0) as c:
            r = await c.get(f"{OLLAMA_BASE}/api/tags")
            if r.status_code == 200:
                ollama_ok = True
                tags = r.json().get("models", [])
                model_base = MODEL.split(":")[0]
                ollama_model_loaded = any(
                    model_base in m.get("name", "") for m in tags
                )
    except Exception:
        pass

    gpu = stt_gpu_stats()

    return JSONResponse({
        "status": "ok" if (stt_model and ollama_ok) else "degraded",
        "components": {
            "vad":  {"status": "ok", "backend": "silero-vad", "device": VAD_DEVICE},
            "stt":  {"status": "ok" if stt_model else "error",
                     "backend": f"faster-whisper {STT_MODEL}",
                     "device": f"{STT_DEVICE} ({STT_COMPUTE})"},
            "llm":  {"status": "ok" if ollama_ok else "error",
                     "backend": f"ollama {MODEL}",
                     "model_loaded": ollama_model_loaded},
            "tts":  {"status": "ok",
                     "backend": "kokoro-82M GPU" if _tts_backend_name() else "edge-tts"},
        },
        "gpu": gpu,
    })


def _tts_backend_name():
    from tts import _kokoro_available
    return _kokoro_available


@app.get("/gpu")
async def gpu_telemetry():
    """Live GPU VRAM stats."""
    if not torch.cuda.is_available():
        return {"cuda": False}
    dev = int(os.environ.get("CUDA_DEVICE", "0"))
    alloc = torch.cuda.memory_allocated(dev)
    resvd = torch.cuda.memory_reserved(dev)
    total = torch.cuda.get_device_properties(dev).total_memory
    return {
        "cuda":         True,
        "device_name":  torch.cuda.get_device_name(dev),
        "allocated_gb": round(alloc / 1024**3, 2),
        "reserved_gb":  round(resvd / 1024**3, 2),
        "total_gb":     round(total / 1024**3, 2),
        "free_gb":      round((total - resvd) / 1024**3, 2),
        "utilization":  f"{resvd / total * 100:.1f}%",
    }


# ── VAD on GPU ────────────────────────────────────────────────────────────────
VAD_DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
CUDA_IDX   = int(os.environ.get("CUDA_DEVICE", "0"))

log.info(f"Loading Silero VAD on {VAD_DEVICE}...")
from silero_vad import load_silero_vad
vad_model = load_silero_vad()
vad_model = vad_model.to(VAD_DEVICE)
vad_model.eval()
log.info(f"Silero VAD ready on {VAD_DEVICE}")

# Pre-allocate a reusable GPU tensor for VAD frames (avoids per-call alloc)
_VAD_FRAME   = 512
_vad_tensor  = torch.zeros(1, _VAD_FRAME, device=VAD_DEVICE)

# ── Constants ─────────────────────────────────────────────────────────────────
SAMPLE_RATE      = 16_000
SPEECH_THRESHOLD = 0.6
SILENCE_LIMIT    = 0.35
MIN_SPEECH_TIME  = 0.15
MAX_AUDIO_SECS   = 10
PARTIAL_INTERVAL = 0.8
BARGE_IN_HOLD    = 0.08
KEEPALIVE_SECS   = 20
PING_MISS_LIMIT  = 2


# ── VAD (runs in thread — torch ops are thread-safe with GIL) ─────────────────

def run_vad(pcm: np.ndarray) -> float:
    """
    Run Silero VAD on GPU.
    Pre-allocated tensor is reused to avoid repeated GPU alloc/free.
    Returns max speech probability across 512-sample frames.
    """
    peak = 0.0
    with torch.no_grad():
        for i in range(0, len(pcm) - _VAD_FRAME + 1, _VAD_FRAME):
            frame = pcm[i: i + _VAD_FRAME]
            # Copy into pre-allocated tensor
            _vad_tensor[0, :] = torch.from_numpy(frame).to(VAD_DEVICE)
            prob = vad_model(_vad_tensor, SAMPLE_RATE).item()
            if prob > peak:
                peak = prob
    return peak


# ── STT (dispatches to pinned GPU thread in stt.py) ───────────────────────────

def run_whisper(audio: np.ndarray) -> str:
    """
    Calls stt.transcribe() which dispatches to the pinned GPU executor.
    Called via asyncio.to_thread() so this blocks the calling thread, not the loop.
    """
    return transcribe(audio)


# ═══════════════════════════════════════════════════════════════════════════════
#  WebSocket endpoint
# ═══════════════════════════════════════════════════════════════════════════════

@app.websocket("/ws")
async def websocket_endpoint(
    ws: WebSocket,
    token: str | None = Query(default=None),
):
    await ws.accept()
    sid = str(uuid.uuid4())[:8]
    s   = get_or_create(token, sid)
    s.connected = True
    log.info(f"[{s.id}] connected (token={'restored' if token else 'new'})")

    await ws.send_json({
        "type":            "session",
        "reconnect_token": s.reconnect_token,
        "session_id":      s.id,
    })

    ka_task     = asyncio.create_task(_keepalive(ws, s))
    sender_task = asyncio.create_task(_sender(ws, s))

    try:
        await _receive_loop(ws, s)
    except WebSocketDisconnect as e:
        log.info(f"[{s.id}] disconnected (code={e.code})")
    except Exception as e:
        log.exception(f"[{s.id}] error: {e}")
    finally:
        s.connected = False
        ka_task.cancel()
        sender_task.cancel()
        await s.cancel_generation()
        await asyncio.gather(ka_task, sender_task, return_exceptions=True)
        log.info(f"[{s.id}] cleanup done")


# ── Receive loop ──────────────────────────────────────────────────────────────

async def _receive_loop(ws: WebSocket, s: SessionState):
    while True:
        msg = await ws.receive()

        if text := msg.get("text"):
            await _handle_control(ws, s, text)
            continue

        raw = msg.get("bytes")
        if not raw:
            continue

        pcm = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0

        if s.state == SessionState.PROCESSING:
            continue

        speech_prob = await asyncio.to_thread(run_vad, pcm)
        chunk_secs  = len(pcm) / SAMPLE_RATE

        if s.state == SessionState.SPEAKING:
            await _check_barge_in(ws, s, speech_prob, chunk_secs, pcm)
            continue

        await _handle_speech_detection(ws, s, speech_prob, chunk_secs, pcm)


# ── Speech detection ──────────────────────────────────────────────────────────

async def _handle_speech_detection(ws, s, prob, chunk_secs, pcm):
    if prob > SPEECH_THRESHOLD:
        if not s.speech_active:
            _start_speech(s, pcm)
            await _enqueue_send(s, {"type": "status", "text": "listening"})
        else:
            s.speech_buffer.append(pcm)
        s.partial_timer += chunk_secs
        if s.partial_timer >= PARTIAL_INTERVAL:
            audio = np.concatenate(s.speech_buffer)[-SAMPLE_RATE * 2:]
            asyncio.create_task(_send_partial(s, audio))
            s.partial_timer = 0.0
    else:
        if s.speech_active:
            s.speech_buffer.append(pcm)
            s.silence_time += chunk_secs
            if s.silence_time >= SILENCE_LIMIT:
                asyncio.create_task(_process_utterance(ws, s))


def _start_speech(s, first_chunk):
    s.speech_active = s.speech_buffer = s.silence_time = s.partial_timer = s.barge_hold_secs = None
    s.speech_active   = True
    s.speech_buffer   = [first_chunk]
    s.silence_time    = 0.0
    s.partial_timer   = 0.0
    s.barge_hold_secs = 0.0
    s.set_state(SessionState.LISTENING)
    log.info(f"[{s.id}] speech started")


async def _send_partial(s, audio):
    try:
        text = await asyncio.to_thread(run_whisper, audio)
        if text:
            await _enqueue_send(s, {"type": "partial", "text": text})
    except Exception as e:
        log.debug(f"[{s.id}] partial error: {e}")


# ── Process utterance ─────────────────────────────────────────────────────────

async def _process_utterance(ws, s):
    s.speech_active = False
    audio = np.concatenate(s.speech_buffer)
    s.reset_speech()

    if len(audio) < SAMPLE_RATE * MIN_SPEECH_TIME:
        s.set_state(SessionState.IDLE)
        return

    if len(audio) > SAMPLE_RATE * MAX_AUDIO_SECS:
        audio = audio[-SAMPLE_RATE * MAX_AUDIO_SECS:]

    s.set_state(SessionState.PROCESSING)
    await _enqueue_send(s, {"type": "status", "text": "thinking"})

    text = await asyncio.to_thread(run_whisper, audio)
    if not text:
        s.set_state(SessionState.IDLE)
        await _enqueue_send(s, {"type": "status", "text": "idle"})
        return

    log.info(f"[{s.id}] user: {text!r}")
    await _enqueue_send(s, {"type": "transcript", "text": text})

    gen_id = s.new_generation()
    await _run_speaking(ws, s, text, gen_id)


# ═══════════════════════════════════════════════════════════════════════════════
#  Speaking pipeline — LLM producer + TTS consumer (concurrent)
# ═══════════════════════════════════════════════════════════════════════════════

async def _run_speaking(ws, s, user_text, gen_id):
    s.set_state(SessionState.SPEAKING)
    s.barge_hold_secs = 0.0
    await _enqueue_send(s, {"type": "status", "text": "speaking"})

    was_interrupted   = s.was_interrupted
    s.was_interrupted = False
    parser = TagParser()

    s.llm_task = asyncio.create_task(
        _llm_producer(s, user_text, parser, gen_id, was_interrupted)
    )
    s.tts_task = asyncio.create_task(_tts_consumer(s, gen_id))

    try:
        await asyncio.gather(s.llm_task, s.tts_task)
    except (asyncio.CancelledError, Exception) as e:
        if not isinstance(e, asyncio.CancelledError):
            log.exception(f"[{s.id}] pipeline error: {e}")

    if not s.cancel_event.is_set():
        s.set_state(SessionState.IDLE)
        await _enqueue_send(s, {"type": "status", "text": "idle"})


async def _llm_producer(s, user_text, parser, gen_id, was_interrupted):
    import re as _re
    _FUNC_RE = _re.compile(r'<function=[^>]*>.*?</function>|<function=[^>]*/>', _re.DOTALL)
    CLIP_EMOTIONS = {"hmm", "laugh", "pause"}

    try:
        async for token in chat_stream(user_text, s.id, was_interrupted):
            s.was_interrupted = False
            if "<function" in token:
                token = _FUNC_RE.sub("", token)
                if not token.strip():
                    continue

            for clean, emo in parser.feed(token):
                if clean.strip() or emo in CLIP_EMOTIONS:
                    await s.tts_queue.put((clean, emo))

            display = parser.get_display_text(token)
            if display:
                await _enqueue_send(s, {
                    "type": "ai_stream", "text": display,
                    "emotion": parser.current_emotion,
                })

        clean, emo = parser.flush()
        if clean.strip():
            await s.tts_queue.put((clean, emo))

    except asyncio.CancelledError:
        log.info(f"[{s.id}] LLM producer cancelled")
        raise
    except Exception as e:
        log.exception(f"[{s.id}] LLM producer error: {e}")
    finally:
        try:
            s.tts_queue.put_nowait(None)
        except asyncio.QueueFull:
            pass


async def _tts_consumer(s, gen_id):
    CLIP_EMOTIONS = {"hmm", "laugh", "pause"}
    try:
        while True:
            item = await s.tts_queue.get()
            if item is None:
                break
            clean, emo = item
            if not clean.strip() and emo not in CLIP_EMOTIONS:
                continue
            audio = await synthesize_chunk(clean, emo)
            if audio:
                await _enqueue_send(s, audio, is_bytes=True)
    except asyncio.CancelledError:
        log.info(f"[{s.id}] TTS consumer cancelled")
        raise
    except Exception as e:
        log.exception(f"[{s.id}] TTS consumer error: {e}")


# ── Serialized sender ─────────────────────────────────────────────────────────

async def _enqueue_send(s, payload, is_bytes=False):
    if s.connected:
        await s.send_queue.put((payload, is_bytes))


async def _sender(ws, s):
    while s.connected:
        try:
            payload, is_bytes = await asyncio.wait_for(s.send_queue.get(), timeout=1.0)
            if is_bytes:
                await ws.send_bytes(payload)
            else:
                await ws.send_json(payload)
        except asyncio.TimeoutError:
            continue
        except Exception as e:
            log.warning(f"[{s.id}] send error: {e}")
            s.connected = False
            break


# ── Keepalive ─────────────────────────────────────────────────────────────────

async def _keepalive(ws, s):
    while s.connected:
        await asyncio.sleep(KEEPALIVE_SECS)
        if not s.connected:
            break
        if s.ping_missed >= PING_MISS_LIMIT:
            log.warning(f"[{s.id}] ping timeout — closing")
            try: await ws.close(1001)
            except Exception: pass
            s.connected = False
            break
        s.ping_missed += 1
        await _enqueue_send(s, {"type": "ping"})


# ── Barge-in ──────────────────────────────────────────────────────────────────

async def _check_barge_in(ws, s, prob, chunk_secs, pcm):
    if prob > SPEECH_THRESHOLD:
        s.barge_hold_secs += chunk_secs
        if s.barge_hold_secs >= BARGE_IN_HOLD:
            await _trigger_interrupt(ws, s, "vad_barge_in")
            _start_speech(s, pcm)
    else:
        s.barge_hold_secs = 0.0


async def _trigger_interrupt(ws, s, reason="unknown"):
    log.warning(f"[{s.id}] ⚡ INTERRUPT ({reason})")
    s.was_interrupted = True
    s.cancel_event.set()
    await s.cancel_generation()
    await _enqueue_send(s, {"type": "interrupt", "reason": reason, "gen_id": s.gen_id})
    s.barge_hold_secs = 0.0
    s.silence_time    = 0.0
    s.set_state(SessionState.LISTENING)


# ── Control messages ──────────────────────────────────────────────────────────

async def _handle_control(ws, s, raw):
    try:
        msg = json.loads(raw)
    except json.JSONDecodeError:
        return
    t = msg.get("type")
    if t == "pong":
        s.ping_missed = 0
    elif t == "interrupt" and s.state == SessionState.SPEAKING:
        await _trigger_interrupt(ws, s, "client_barge_in")


# ═══════════════════════════════════════════════════════════════════════════════
#  Entry point
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import uvicorn

    if torch.cuda.is_available():
        dev = torch.cuda.get_device_properties(0)
        log.info(f"GPU: {dev.name} | {dev.total_memory/1024**3:.1f}GB VRAM")
        log.info(f"CUDA {torch.version.cuda} | cuDNN {torch.backends.cudnn.version()}")
    else:
        log.warning("No CUDA GPU detected — running on CPU")

    log.info("=" * 55)
    log.info("  GPU Voice Agent")
    log.info(f"  VAD:  Silero on {VAD_DEVICE}")
    log.info(f"  STT:  faster-whisper large-v3 on CUDA")
    log.info(f"  LLM:  Ollama {MODEL} (num_gpu=-1)")
    log.info(f"  TTS:  Kokoro-82M on CUDA")
    log.info("=" * 55)

    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=False,
        log_level="info",
        workers=1,       # single worker — GPU context is not fork-safe
    )
